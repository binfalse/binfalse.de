package PERIODENSYSTEM;

//die klasse element
public class Element
{
    //besitzt eine schlange von isotopen
    public Queue isos;
    //jedes element hat elektronegativit�t
    public double elekneg;
    //einen namen
    public String name;
    //und ein chemisch eindeutiges zeichen
    public String zeichen;
    /**
     *Konstruktor zum Erzeugen eines Elements
     */
    public Element ()
    {
        elekneg = 0;
        name = "";
        zeichen = "";
        isos = new Queue ();
    }
}

