package BAUM;

//der passende node zum baum, aber auch zu den 
//arrays/vektoren in die er sp�ter umgeschrieben wird
public class Node
{

    /** Creates a new instance of Node */
	public double percent;
	public double weight;
	public Node kinder [];
}

