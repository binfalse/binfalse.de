package EINGABE;

//das stackelement
class stack_elem
{
	public char wert;
	public stack_elem next;
}

//der stack f�r die korrekte klammersetzung
public class Stack 
{
    //den einstiegspunkt definieren
    private stack_elem oben;
    //und die gr��e des stacks festlegen
    private int counter;
    /**
     *Konstruktor zum erzeugen eines Stapels auf den die einzelnen buchstaben gepackt werden um sp�ter das gesamte element zu �berpr�fen
     */
    public Stack()
    {
	oben=null;
	counter=0;
    }
    /**
     *legt ein neues element auf den stapel
     */
    public void push(char a)
    {
	//neues element erzeugen
	stack_elem temp=new stack_elem(); 
	//bekommt den aktuellen buchstaben
	temp.wert=a;
	//wenn noch kein element im stack wirds das erste
	if(counter==0)
	{
	    oben=temp;
	    oben.next=null;
	}//ansonsten wird es eingebaut
	else
	{
	    stack_elem temp1=new stack_elem();
	    stack_elem neu=new stack_elem();
	    neu.wert=a;
	    temp1=oben;
	    oben=neu;
	    oben.next=temp1;
	}
	counter++;
    }
    /**
     *holt das oberste element vom stapel und liefert es
     */
    public char top()
    {
	//wenn leer -> leer returnen
	if(counter==0) return ' ';
	//ansonsten den ersten wert
	return oben.wert;	
    }
    /**
     *schmei�t das oberste element vom stapel
     */
    public void pop()
    {
	//wenn kein element -> ohne wert zur�ck
	if(counter==0) return;
	//ansonsten oben weitersetzen
	oben=oben.next;
	counter--;
    }
    /**
     *�berpr�ft ob elemente im stapel vorhanden
     */
    public boolean isEmpty()
    {
	return (counter==0);
    }

}
