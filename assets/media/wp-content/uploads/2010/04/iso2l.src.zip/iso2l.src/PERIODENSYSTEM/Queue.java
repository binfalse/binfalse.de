package PERIODENSYSTEM;

//Die Isotopenschlange
//imprinzip eine modifizierte standartschlange,
//nat�rlich nur mit den methoden die wir hier auch wirklich brauchen
public class Queue
{
    //start, ende und l�nge der schlange
    private Isotops start;
    private Isotops ende;
    private int laenge;
    /**
     *Konstruktor zum Erzeugen der Schlange f�r die Isotope
     */
    public Queue()
    {
        start = null;
        ende = null;
        laenge = 0;
    }
    /**
     *f�gt ein neues Isotop in die Schlange ein
     */
    public boolean nach_hinten(double percent, double weight)
    {
            if (laenge == 0)
            {//wenn nichts in der liste einfach neues elem erzeugen
                    //und start und ende draufzeigen lassen
                    start = new Isotops(percent, weight);
                    if (start == null) return false;
                    ende = start;
                    //laenge erhoehen
                    laenge++;
                    return true;
            }
            //wenn liste nicht leer
            //neues element erstellen
            Isotops neu = new Isotops(percent, weight);
            if (neu == null) return false;
            //neues zeigt auf vorletztes
            neu.prev = ende;
            //vorletztes zeigt auf neues
            ende.next = neu;
            //ende zeigt auf neues ende
            ende = neu;
            //laenge erhoehen
            laenge++;
            return true;

    }
    /**
     * liefert die Anzahl der Isotopen zu einem Element
     */
    public int laenge()
    {
            return laenge;
    }
    /**
     * �berpr�ft ob es zu dem Element �berhaupt Isotope gibt
     */
    public boolean is_leer()
    {
            return (laenge == 0);
    }
    /**
     *gibt ein array vom Typ Isotops zur�ck. Enthalten: Die jeweiligen Isotope eines Elements
     */
    public Isotops [] gib_isos()
    {
	//array anlegen
        Isotops [] array = new Isotops [laenge];
	//vorn anfangen
        Isotops current = start;
	//�ber die schlange laufen
        for (int i = 0; i < laenge; i++)
        {
	    //array f�llen
            array[i] = new Isotops();
            array[i].percent = current.percent;
            array[i].weight = current.weight;
            current = current.next;
        }
	//array zur�ckgeben
        return array;
    }
    /**
     * liefert den Einsprungspunkt in die Schlange von Isotopen
     */
    public Isotops give_head()
    {
        return start;
    }
}
