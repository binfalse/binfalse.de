package EINGABE;

//das objekt was eingelesen wird
public class element_object
{
	public String zeichen;		
	public int ord;
	public double anzahl;
	public element_object next;
	public element_object prev;
	public double isos;
}
