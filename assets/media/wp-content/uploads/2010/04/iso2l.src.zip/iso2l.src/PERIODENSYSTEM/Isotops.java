package PERIODENSYSTEM;

//die klasse der isotopen
public class Isotops
{
    //gespeichert werden die eigenschaften der isotopen
    public double percent;
    public double weight;
    //und f�r die schlange noch die next und prev zeiger
    public Isotops next;
    public Isotops prev;
    /**
     *Konstruktor zum erzeugen eines neuen Isotops
     */
    public Isotops()
    {
        percent = 1;
        weight = 1;
        next = null;
        prev = null;
    }
    /**
     *�berschriebener Konstruktor, falls man schon gleich wei� welche werte das Isotop hat
     */
    public Isotops(double percent, double weight)
    {
        this.percent = percent;
        this.weight = weight;
        next = null;
        prev = null;
    }
}
