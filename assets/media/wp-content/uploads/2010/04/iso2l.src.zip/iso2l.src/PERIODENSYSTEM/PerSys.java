package PERIODENSYSTEM;

//das ber�hmt ber�chtigte periodensystem
public class PerSys
{
    /**
     *das Array mit den Elementen und ihren Isotopen
     */
    public Element [] elemente;
    /**
     *Der Konstruktoer erzeugt ein neues Periodensystem
     */
    public PerSys (int anz)
    {
        elemente = new Element [anz];
        for (int i = 0; i < anz; i++)
            elemente[i] = new Element ();
    }
    
}
    
