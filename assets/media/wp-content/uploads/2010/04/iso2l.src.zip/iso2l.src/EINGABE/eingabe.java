package EINGABE;

import java.io.*;
import java.lang.*;
import java.util.Vector;
import java.math.*;

import PERIODENSYSTEM.*;

public class eingabe 
{
	//der vektor in dem die elemente und ihre anzahl in der formel gespeichert werden
private Vector elemente=new Vector();
	
	//funktion die ein element als string und dessen anzahl in dem vektor speichert
	private void einfuegen(String a, int b, int ord, PerSys per)
	{
/*
*wenn der vektor leer ist wird das element normal ohne andere pruefung in    
*dem vektor gespeichert, als objekt vom typ element_object 
*/
if(elemente.isEmpty()) 
		{	
			element_object huhu=new element_object();
			huhu.zeichen=a;
			huhu.anzahl=b;
                        	huhu.ord = ord;
                        	huhu.isos = per.elemente[ord].isos.laenge();
			elemente.addElement(huhu);
			return;
		}
		element_object obj;
/*
*falls vektor bereits elemente enthaelt, so wird geschaut ob das element was  
*eingefuegt werden soll bereits enthalten ist
*wenn das der fall ist, so wird in dem vektor an dessen stelle nur die anzahl    des elements dazu addiert
*/
for(int i=0;i<elemente.size();i++)
		{
			obj=(element_object)elemente.elementAt(i);
			if((obj.zeichen).equals(a)) 
			{
				obj.anzahl+=b;
				return;
			}
		}	
/*
*wenn das element nicht enthalten ist so wird ein neues objekt angelegt, der *name des elementes und dessen anzahl abgespeichert und dem vektor *beigefuegt
*/
element_object huhu=new element_object();
		huhu.zeichen=a;
		huhu.anzahl=b;
                	huhu.ord = ord;
                	huhu.isos = per.elemente[ord].isos.laenge();
		elemente.addElement(huhu);
		return;
	}	
	
/*
*diese funktion castet eine zahl, die als string �bergeben wird zu einem integer, da mit *diesem wert sp�ter gerechnet werden muss
*/
	private int zahl(String ziffer)
	{
		int a=0;
		for(int i=(ziffer.length()-1),j=0;i>=0;i--,j++)
		{
			a+=Character.digit(ziffer.charAt(i), 10)*Math.pow(10, j);
		}
		return a;
	}
	
/*
*die hauptfunktion der eingabeklasse, die die richtigkeit des eingebenen strings *kontrolliert, �bergebene parameter sind der string, die anzahl (f�r klammern wichtig) *und das periodensystem als persys-objekt zur existenzkontrolle der eingegebenen *elemente
*/
	private boolean control(String formel, int anzahl, PerSys per)
	{
		if(formel.equals("")) return false;
/* 
*& dient dabei als �stoppsignal� des strings und wird an jeden string *angehaengt
*/
formel+='&';
		char wert;
		int i=0;
		//kontrollschleife, die ueber alle elemente des strings laeuft
while(i<(formel.length()-1))
		{
			wert=formel.charAt(i);
			//wenn grossbuchstabe
			if(Character.isUpperCase(wert))
			{
				String a="";
				//wird in tempor�ren string gespeichert
a+=wert;
				wert=formel.charAt(++i);
				//wenn kleinbuchstabe
				if(Character.isLowerCase(wert))
				{
					//wird dam string angefuegt, element komplett
a+=wert;
					wert=formel.charAt(++i);
				}
                                		//pruefen ob element im periodensystem vorkommt
int ord = exists(a, per);
                                		//wenn ja
if (ord != -1)
                                		{
                                    		//schauen ob ziffer nach dem element steht
String ziffer="";
                                    		while(Character.isDigit(wert))
                                    		{
                                            			ziffer+=wert;
                                            			wert=formel.charAt(++i);
                                    		}
                                    		//aufruf von einfuegen() mit dem element und der anzahl
if(ziffer.equals("")) 
                                    		{
                                            			einfuegen(a, 1*anzahl, ord, per);
                                    		}
                                    		else
                                    		{
                                            			einfuegen(a, zahl(ziffer)*anzahl, ord, per);
                                    		}
                                    		continue;
                              	  }
                              	 //wenn element nicht im periodensystem 
 else return false;
		}
			
//wenn oeffnende klammer
		if(wert=='(')
		{
			String teilformel="";
			Stack klammer=new Stack();
			//wird in stack eingefuegt
klammer.push('(');
			i++;
			/*
*nun wird solange ueber string iteriert bis der string beendet ist bzw
*bis der stack leer ist
*/
while(true)
			{
				if(i==(formel.length()-1)) {int ende=1;break;}
				wert=formel.charAt(i);
				if(wert=='(') klammer.push('(');
				if(wert==')') 
				{
					if(klammer.top()=='(') 
					{	
						klammer.pop();
					}
					else klammer.push(')');		
				}
				if(klammer.isEmpty()) break;
				//string in dem der inhalt der klammer gespeichert wird
teilformel+=wert;
				i++;	
			}
if(!klammer.isEmpty()) return false;
			else 
			{
				//pruefen, ob nach letzter klammer eine ziffer folgt
String a="";
				wert=formel.charAt(++i);
				while(Character.isDigit(wert))
				{
					a+=wert;
					wert=formel.charAt(++i);
				}
				//rekursion mit der teilformel und der ziffer als faktor
if(a.equals("")) control(teilformel, 1*anzahl, per);
				else control(teilformel, zahl(a)*anzahl, per);
			}			
			continue;
		}
		if(wert=='&') return true;
		return false;
	}
	if(elemente.isEmpty()) return false;
	else return true;
}
/**
 *funktion �bergibt formel an control-funktion 
 *�berpr�ft die Eingabe, liefert einen Vektor wenn Eingabe korrekt, ansonsten "null"
 */
public Vector scan (String eingabe, PerSys per)
{
	//eingabe in=new eingabe();
	if(!control(eingabe, 1, per)) return null;
	//else if (!check_elements(per)) return null;
               else return elemente;
}
 
//function prueft, ob ein eingegebenes element im periodensystem enthalten ist 
private int exists (String zeichen, PerSys per)
{
         for (int j = 0; j < per.elemente.length; j++)
         {
                if (zeichen.equals (per.elemente[j].zeichen))
                {
                    return j;
                }
         }
         return -1;
}
}