
iso2l

Wir sind eine kleine Gruppe von Studenten
der Martin-Luther-Universität Halle-Wittenberg,
die im Sinne eines Projekts dieses Tool entwickelten.

visit: http://www.iso2l.de.vu

Team
Martin Scharm
Christoph Ruttkies
Steffi Dornfeldt

